// src/pages/Ingredients.tsx
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  TableContainer,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  CircularProgress,
  Typography,
} from "@mui/material";
import { useIngredients, useAddIngredient, useDeleteIngredient, useUpdateIngredient, useInventory } from "../hooks/useApi";
import { useState } from "react";
import { VoiceInput } from "../components/VoiceInput";

export const Ingredients = () => {
  const { data:ingredients = [], isLoading, error } = useIngredients();
  const { data: inventory = [], isLoading: inventoryLoading } = useInventory();
  const addIngredient = useAddIngredient();
  const updateIngredient = useUpdateIngredient();
  const deleteIngredient = useDeleteIngredient();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [unit, setUnit] = useState("");
  const [minStock, setMinStock] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);

  const handleSave = async () => {
    const threshold = Number(minStock);
    if (!name.trim() || !unit.trim() || !Number.isFinite(threshold) || threshold < 0) { alert("Enter valid ingredient details and a non-negative minimum stock."); return; }
    if (editingId) await updateIngredient.mutateAsync({ id: editingId, name, base_unit: unit, min_stock: threshold });
    else await addIngredient.mutateAsync({ name, base_unit: unit, min_stock: threshold });
    setOpen(false);
    setName("");
    setUnit("");
    setMinStock("");
    setEditingId(null);
  };

  const editIngredient = async (ingredient: any) => {
    setEditingId(ingredient.id);
    setName(ingredient.name);
    setUnit(ingredient.base_unit);
    setMinStock(String(ingredient.min_stock ?? 0));
    setOpen(true);
  };

  const removeIngredient = async (ingredient: any) => {
    if (window.confirm(`Delete ${ingredient.name}?`)) {
      try { await deleteIngredient.mutateAsync({ id: ingredient.id }); }
      catch (requestError: any) { alert(requestError.response?.data?.detail || "Could not delete ingredient."); }
    }
  };

  return (
    <Box>
      <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1.5, alignItems: "center", justifyContent: "space-between", mb: 2 }}>
        <Typography variant="h4">Ingredients</Typography>
        <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
          <VoiceInput onResult={(json) => {
            try {
              const parsed = JSON.parse(json);
              const item = parsed.items?.[0] || parsed;
              setEditingId(null);
              setName(item.name || "");
              setUnit(item.unit || "");
              setMinStock(item.minStock ? String(item.minStock) : "");
              setOpen(true);
            } catch { /* ignore */ }
          }} label="Quick voice ingredient" variant="ingredient" />
          <Button variant="contained" onClick={() => { setEditingId(null); setName(""); setUnit(""); setMinStock(""); setOpen(true); }}>
            Add Ingredient
          </Button>
        </Box>
      </Box>

      {isLoading ? (
        <CircularProgress />
      ) : error ? (
        <Typography color="error">{(error as any).message}</Typography>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Name</TableCell>
                <TableCell>Unit</TableCell>
                <TableCell>On-hand</TableCell>
                <TableCell>Average Cost</TableCell>
                <TableCell>Minimum Stock</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {ingredients?.map((ing: any) => {
                const stock = inventory.find((item: any) => item.id === ing.id);
                return (
                <TableRow key={ing.id}>
                  <TableCell>{ing.id}</TableCell>
                  <TableCell>{ing.name}</TableCell>
                  <TableCell>{ing.base_unit}</TableCell>
                  <TableCell>{inventoryLoading || !stock ? <CircularProgress size={14} /> : stock.on_hand_qty}</TableCell>
                  <TableCell>{inventoryLoading || !stock ? <CircularProgress size={14} /> : `₹${(stock.avg_unit_price ?? 0).toFixed(2)}`}</TableCell>
                  <TableCell>{ing.min_stock ?? 0}</TableCell>
                  <TableCell>{inventoryLoading || !stock ? <CircularProgress size={14} /> : <Typography color={stock.is_low_stock ? "error" : "success.main"}>{stock.is_low_stock ? "Low stock" : "OK"}</Typography>}</TableCell>
                  <TableCell><Button size="small" onClick={() => editIngredient(ing)}>Edit</Button><Button size="small" color="error" onClick={() => removeIngredient(ing)} disabled={deleteIngredient.isPending}>Delete</Button></TableCell>
                </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* ---------- Add dialog ---------- */}
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>{editingId ? "Edit Ingredient" : "Add Ingredient"}</DialogTitle>
        <DialogContent>
          <TextField
            margin="dense"
            label="Name"
            fullWidth
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            margin="dense"
            label="Minimum stock alert level"
            type="number"
            fullWidth
            value={minStock}
            onChange={(e) => setMinStock(e.target.value)}
            slotProps={{ htmlInput: { min: 0, step: "any" } }}
          />
          <TextField
            margin="dense"
            label="Unit (e.g. kg, L, pcs)"
            fullWidth
            value={unit}
            onChange={(e) => setUnit(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleSave} variant="contained" disabled={addIngredient.isPending || updateIngredient.isPending}>
            {(addIngredient.isPending || updateIngredient.isPending) ? <CircularProgress size={20} color="inherit" /> : (editingId ? "Update" : "Save")}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
