﻿import { Alert, Box, Button, Card, CardContent, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, FormControl, InputLabel, MenuItem, Paper, Select, Snackbar, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography, useMediaQuery, useTheme } from "@mui/material";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import { useBatchDetail, useBatches, useCostPreview, useProduceBatch, useRecipes, useUpdateBatch } from "../hooks/useApi";
import { EmptyState, ErrorState, FormActions, FormSection, PageHeader, TableSkeleton } from "../components/ui";
import { useState } from "react";
import { PieChart, Pie, Cell, Tooltip as RechartsTooltip, ResponsiveContainer, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { VoiceInput } from "../components/VoiceInput";
import { bestMatch } from "../utils/fuzzy";
import { formatDate } from "../utils/formatDate";
import { formatMoney } from "../utils/formatNumber";

const COLORS = ["#1976d2", "#388e3c", "#f57c00", "#d32f2f", "#7b1fa2", "#00796b", "#fbc02d", "#5d4037"];

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <Box sx={{ bgcolor: "white", border: 1, borderColor: "divider", borderRadius: 2, px: 2, py: 1, boxShadow: 1 }}>
      <Typography variant="caption" sx={{ fontWeight: 700 }}>{payload[0].name}</Typography>
      <Typography variant="caption" sx={{ display: "block" }}>{formatMoney(Number(payload[0].value))} ({((Number(payload[0].value) / Number(payload[0].payload.total)) * 100).toFixed(0)}%)</Typography>
    </Box>
  );
};

export const Production = () => {
  const { data: recipes = [], isLoading: recipesLoading } = useRecipes();
  const { data: batches = [], isLoading: batchesLoading, error: batchesError, refetch: refetchBatches } = useBatches(50);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const produce = useProduceBatch();
  const updateBatch = useUpdateBatch();
  const [open, setOpen] = useState(false);
  const [recipeId, setRecipeId] = useState(0);
  const [producedQty, setProducedQty] = useState("");
  const [scaleMode, setScaleMode] = useState<"output" | "batches">("output");
  const [batchCount, setBatchCount] = useState("1");
  const [method, setMethod] = useState<"FIFO" | "LIFO" | "AVG">("AVG");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const { data: preview, isFetching: previewLoading } = useCostPreview(recipeId, producedQty);
  const [detailId, setDetailId] = useState<number | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [editQty, setEditQty] = useState("");
  const [editDate, setEditDate] = useState("");
  const [editPrice, setEditPrice] = useState("");
  const { data: detail, isFetching: detailLoading } = useBatchDetail(detailId);

  const openEdit = () => {
    if (!detail) return;
    setEditQty(String(detail.produced_qty));
    setEditDate(new Date(detail.produced_at).toISOString().slice(0, 10));
    setEditPrice(detail.total_revenue == null ? "" : String(detail.total_revenue));
    setEditOpen(true);
  };

  const saveEdit = async () => {
    if (!detailId || !detail || !editDate) return;
    try {
      await updateBatch.mutateAsync({ id: detailId, produced_qty: detail.produced_qty, produced_at: new Date(`${editDate}T00:00:00`).toISOString(), selling_price: editPrice ? Number(editPrice) : null });
      setEditOpen(false);
      setSuccess(`Batch #${detailId} updated.`);
    } catch (requestError: any) {
      setError(requestError.response?.data?.detail || "Could not update the batch.");
    }
  };

  const close = () => { setOpen(false); setError(""); };
  const submit = async () => {
    const quantity = scaleMode === "batches" ? Number(batchCount) * (recipes.find((recipe: any) => recipe.id === recipeId)?.batch_qty || 0) : Number(producedQty);
    if (!recipeId || !Number.isFinite(quantity) || quantity <= 0) { setError("Choose a recipe and enter a quantity greater than zero."); return; }
    try {
      const batch = await produce.mutateAsync({ recipe_id: recipeId, produced_qty: quantity, costing_method: method });
      setSuccess(`Batch #${batch.id} recorded successfully.`); close(); setProducedQty(""); setBatchCount("1");
    } catch (requestError: any) { setError(requestError.response?.data?.detail || "Could not record the batch."); }
  };

  const cellSx = { py: 0.75, px: 1, fontSize: { xs: "0.7rem", sm: "0.8rem" } };

  const handleProdVoice = (json: string) => {
    try {
      const parsed = JSON.parse(json);
      const item = parsed.items?.[0] || parsed;
      const matchRecipe = bestMatch(recipes, item.name);
      if (matchRecipe) setRecipeId(matchRecipe.id);
      setScaleMode("output");
      setProducedQty(item.qty ? String(item.qty) : "");
      setBatchCount("1");
      setMethod("AVG");
      setError("");
      setOpen(true);
    } catch { /* ignore */ }
  };

  return <Box>
    <PageHeader
      title="Production"
      subtitle="Record batches and review recent output."
      actions={
        <>
          <VoiceInput onResult={handleProdVoice} disabled={!recipes.length} label="Quick voice batch" variant="production" />
          <Button startIcon={<AddRoundedIcon />} variant="contained" onClick={() => setOpen(true)} disabled={!recipes.length}>Record batch</Button>
        </>
      }
    />
    <Card sx={{ mb: 2, background: "primary.main", color: "white" }}><CardContent sx={{ p: { xs: 1.5, sm: 2 }, "&:last-child": { pb: { xs: 1.5, sm: 2 } } }}><Typography variant="overline" sx={{ opacity: .8, fontSize: "0.65rem" }}>Production history</Typography><Typography variant="h5" sx={{ fontWeight: 700, fontSize: { xs: "1.25rem", sm: "1.5rem" } }}>{batchesLoading ? <CircularProgress size={22} sx={{ color: "white" }} /> : `${batches.length} batches recorded`}</Typography></CardContent></Card>
    <Box sx={{ display: { xs: "none", sm: "block" } }}>
    <TableContainer component={Paper} sx={{ overflowX: "auto" }}>
      <Table size="small" sx={{ minWidth: 720 }}><TableHead><TableRow><TableCell sx={{ ...cellSx, fontWeight: 700 }}>#</TableCell><TableCell sx={{ ...cellSx, fontWeight: 700 }}>Recipe</TableCell><TableCell sx={{ ...cellSx, fontWeight: 700 }}>Date</TableCell><TableCell sx={{ ...cellSx, fontWeight: 700 }}>Qty</TableCell><TableCell sx={{ ...cellSx, fontWeight: 700 }}>Cost</TableCell><TableCell sx={{ ...cellSx, fontWeight: 700 }}>Cost/Unit</TableCell><TableCell sx={{ ...cellSx, fontWeight: 700 }}>Profit</TableCell><TableCell sx={{ ...cellSx, fontWeight: 700 }}>Details</TableCell></TableRow></TableHead><TableBody>
        {batchesLoading ? <TableSkeleton rows={5} colSpan={8} /> : batchesError ? <TableRow><TableCell colSpan={8} align="center"><ErrorState message={(batchesError as any).message} onRetry={() => refetchBatches()} /></TableCell></TableRow> : batches.length ? batches.map((batch: any) => <TableRow key={batch.id} hover><TableCell sx={cellSx}>{batch.id}</TableCell><TableCell sx={{ ...cellSx, fontWeight: 600 }}>{batch.recipe_name}</TableCell><TableCell sx={cellSx}>{formatDate(batch.produced_at)}</TableCell><TableCell sx={cellSx} className="tnum">{batch.produced_qty}</TableCell><TableCell sx={cellSx} className="tnum">{formatMoney(batch.total_cost)}</TableCell><TableCell sx={cellSx} className="tnum">{formatMoney(batch.total_cost / batch.produced_qty)}</TableCell><TableCell sx={{ ...cellSx, color: (batch.profit ?? 0) >= 0 ? "success.main" : "error.main", fontWeight: 700 }} className="tnum">{batch.profit == null ? "—" : formatMoney(batch.profit)}</TableCell><TableCell sx={cellSx}><Button size="small" onClick={() => setDetailId(batch.id)} aria-label={`View batch ${batch.id}`}>View</Button></TableCell></TableRow>) : <TableRow><TableCell colSpan={8} align="center" sx={{ ...cellSx, py: 3 }}><EmptyState title="No production batches recorded yet." message="Record your first batch to track production costs." actionLabel="Record batch" onAction={() => setOpen(true)} /></TableCell></TableRow>}
      </TableBody></Table>
    </TableContainer>
    </Box>
    <Box sx={{ display: { xs: "block", sm: "none" } }}>
      {batchesLoading ? (
        <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}><CircularProgress /></Box>
      ) : batchesError ? (
        <ErrorState message={(batchesError as any).message} onRetry={() => refetchBatches()} />
      ) : batches.length ? (
        <Stack spacing={1.5}>
          {batches.map((batch: any) => (
            <Card key={batch.id} variant="outlined">
              <CardContent sx={{ p: 2, "&:last-child": { pb: 2 } }}>
                <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 1 }}>
                  <Box sx={{ minWidth: 0 }}>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, fontSize: "0.9375rem" }}>{batch.recipe_name}</Typography>
                    <Typography variant="caption" color="text.secondary">Batch #{batch.id} · {formatDate(batch.produced_at)}</Typography>
                  </Box>
                  <Typography variant="body2" sx={{ fontWeight: 700, whiteSpace: "nowrap", color: (batch.profit ?? 0) >= 0 ? "success.main" : "error.main" }} className="tnum">
                    {batch.profit == null ? "—" : formatMoney(batch.profit)}
                  </Typography>
                </Box>
                <Box sx={{ display: "flex", gap: 2, mt: 1 }} className="tnum">
                  <Box><Typography variant="caption" color="text.secondary" sx={{ display: "block" }}>Quantity</Typography><Typography variant="body2" sx={{ fontWeight: 600 }}>{batch.produced_qty}</Typography></Box>
                  <Box><Typography variant="caption" color="text.secondary" sx={{ display: "block" }}>Cost</Typography><Typography variant="body2" sx={{ fontWeight: 600 }}>{formatMoney(batch.total_cost)}</Typography></Box>
                  <Box><Typography variant="caption" color="text.secondary" sx={{ display: "block" }}>Cost / unit</Typography><Typography variant="body2" sx={{ fontWeight: 600 }}>{formatMoney(batch.total_cost / batch.produced_qty)}</Typography></Box>
                </Box>
                <Button fullWidth variant="outlined" onClick={() => setDetailId(batch.id)} aria-label={`View batch ${batch.id}`} sx={{ mt: 1.5, minHeight: 44 }}>
                  View details
                </Button>
              </CardContent>
            </Card>
          ))}
        </Stack>
      ) : (
        <EmptyState title="No production batches recorded yet." message="Record your first batch to track production costs." actionLabel="Record batch" onAction={() => setOpen(true)} />
      )}
    </Box>
    <Dialog open={open} onClose={close} fullScreen={isMobile} maxWidth="sm" fullWidth><DialogTitle sx={{ fontWeight: 750 }}>Record a batch</DialogTitle><DialogContent sx={{ pb: 1 }}>
      <FormSection title="Recipe">
      <FormControl fullWidth margin="dense" disabled={recipesLoading}><InputLabel>{recipesLoading ? "Loading recipes..." : "Recipe"}</InputLabel><Select value={recipeId} label={recipesLoading ? "Loading recipes..." : "Recipe"} onChange={(event) => { const id = Number(event.target.value); setRecipeId(id); if (scaleMode === "batches") { const recipe = recipes.find((item: any) => item.id === id); if (recipe) setProducedQty(String(Number(batchCount) * recipe.batch_qty)); } }}>{recipes.map((recipe: any) => <MenuItem key={recipe.id} value={recipe.id}>{recipe.name}</MenuItem>)}</Select></FormControl>
      </FormSection>
      <FormSection title="Quantity">
      <FormControl fullWidth margin="dense"><InputLabel>Scale by</InputLabel><Select value={scaleMode} label="Scale by" onChange={(event) => setScaleMode(event.target.value as "output" | "batches")}><MenuItem value="output">Desired output quantity</MenuItem><MenuItem value="batches">Number of batches</MenuItem></Select></FormControl>
      {scaleMode === "output" ? <TextField margin="dense" label="Desired output quantity" type="number" slotProps={{ htmlInput: { inputMode: "decimal", min: 0 } }} fullWidth value={producedQty} onChange={(event) => setProducedQty(event.target.value)} /> : <TextField margin="dense" label="Number of batches" type="number" slotProps={{ htmlInput: { inputMode: "decimal", min: 0 } }} fullWidth value={batchCount} onChange={(event) => { const count = event.target.value; setBatchCount(count); const recipe = recipes.find((item: any) => item.id === recipeId); if (recipe) setProducedQty(String(Number(count) * recipe.batch_qty)); }} />}
      </FormSection>
      <FormSection title="Costing">
      <FormControl fullWidth margin="dense"><InputLabel>Costing method</InputLabel><Select value={method} label="Costing method" onChange={(event) => setMethod(event.target.value as any)}><MenuItem value="FIFO">FIFO</MenuItem><MenuItem value="LIFO">LIFO</MenuItem><MenuItem value="AVG">Weighted average</MenuItem></Select></FormControl>
      </FormSection>
      {previewLoading && <CircularProgress size={20} sx={{ mt: 2 }} />}
      {preview && <Box sx={{ mt: 2, p: 2, borderRadius: 2, bgcolor: "action.hover" }}><Typography sx={{ fontWeight: 700 }}>Live cost preview</Typography><Typography variant="body2">Scale: {preview.batch_multiplier}× · Estimated cost: {formatMoney(preview.estimated_total_cost)}{preview.estimated_profit != null ? ` · Estimated profit: ${formatMoney(preview.estimated_profit)}` : ""}{preview.estimated_margin_pct != null ? ` · Margin: ${preview.estimated_margin_pct.toFixed(2)}%` : ""}</Typography>{preview.lines.map((line: any) => <Typography key={line.ingredient_id} variant="caption" sx={{ display: "block" }} color={line.is_short ? "error.main" : "text.secondary"}>{line.ingredient_name}: need {line.needed_qty} {line.unit} ({formatMoney(line.estimated_cost)}), in stock {line.on_hand_qty}{line.is_short ? " — insufficient" : ""}</Typography>)}{preview.overheads && preview.overheads.length > 0 && <Typography variant="caption" sx={{ display: "block", mt: 1, fontWeight: 600 }} color="text.secondary">Overheads: {formatMoney(preview.estimated_overhead_cost)}</Typography>}{preview.lines.some((line: any) => line.is_short) && <Alert severity="error" sx={{ mt: 1 }}>Insufficient stock. Add the missing ingredients before recording this batch.</Alert>}</Box>}
    </DialogContent><FormActions onCancel={close} submitLabel="Record batch" onSubmit={submit} pending={produce.isPending} disabled={!!preview?.lines.some((line: any) => line.is_short)} error={error} /></Dialog>
    <Dialog open={!!detailId} onClose={() => setDetailId(null)} fullScreen={isMobile} maxWidth="md" fullWidth><DialogTitle>Batch details</DialogTitle><DialogContent>{detailLoading ? <CircularProgress /> : detail && <Box><Box sx={{ display: "flex", gap: 2, mb: 1, p: 1.5, borderRadius: 1, bgcolor: "action.hover" }}><Typography variant="body2"><strong>Cost per unit:</strong> {formatMoney(detail.total_cost / detail.produced_qty)}</Typography><Typography variant="body2"><strong>Qty:</strong> {detail.produced_qty}</Typography><Typography variant="body2"><strong>Method:</strong> {detail.costing_method}</Typography></Box><Typography><strong>#{detail.id} {detail.recipe_name}</strong> · {detail.produced_qty} output · {detail.costing_method}</Typography><Typography sx={{ mt: 1 }}>Cost: {formatMoney(detail.total_cost)} · Revenue: {detail.total_revenue == null ? "—" : formatMoney(detail.total_revenue)} · Profit: {detail.profit == null ? "—" : formatMoney(detail.profit)} · Margin: {detail.margin_pct == null ? "—" : `${detail.margin_pct.toFixed(2)}%`}</Typography>
      {/* Batch Costing Breakdown Pie Chart */}
      <Box sx={{ mt: 2, mb: 1 }}><Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>Cost Breakdown</Typography>
        <ResponsiveContainer width="100%" height={220}>
          <PieChart>
            <Pie data={[
              ...detail.consumptions.map((item: any, i: number) => ({ name: item.ingredient_name, value: item.line_cost, total: detail.total_cost })),
              ...(detail.overheads || []).map((oh: any) => ({ name: oh.name, value: oh.cost, total: detail.total_cost })),
            ].map((item, i) => ({ ...item, fill: COLORS[i % COLORS.length] }))} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={80} labelLine={false} label={false}>
              {[
                ...detail.consumptions.map((_: any, i: number) => <Cell key={`ing-${i}`} fill={COLORS[i % COLORS.length]} />),
                ...(detail.overheads || []).map((_: any, i: number) => <Cell key={`oh-${i}`} fill={COLORS[(detail.consumptions.length + i) % COLORS.length]} />),
              ]}
            </Pie>
            <RechartsTooltip content={<CustomTooltip />} />
            <Legend wrapperStyle={{ fontSize: 10 }} />
          </PieChart>
        </ResponsiveContainer>
      </Box>
      <Box sx={{ mt: 2, mb: 1 }}><Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>Ingredient Cost Trend</Typography>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={detail.consumptions.map((item: any) => ({ name: item.ingredient_name, cost: item.line_cost }))}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" tick={{ fontSize: 10 }} />
            <YAxis tick={{ fontSize: 10 }} />
            <RechartsTooltip formatter={(value: any) => formatMoney(value)} />
            <Bar dataKey="cost" fill="#1976d2" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Box>
      <TableContainer component={Paper} sx={{ mt: 1, overflowX: "auto" }}><Table size="small" sx={{ minWidth: 440 }}><TableHead><TableRow><TableCell>Ingredient</TableCell><TableCell>Quantity</TableCell><TableCell>Unit cost</TableCell><TableCell>Line cost</TableCell></TableRow></TableHead><TableBody>{detail.consumptions.map((item: any, index: number) => <TableRow key={`${item.ingredient_name}-${index}`}><TableCell>{item.ingredient_name}</TableCell><TableCell>{item.qty_used}</TableCell><TableCell>{formatMoney(item.unit_cost)}</TableCell><TableCell>{formatMoney(item.line_cost)}</TableCell></TableRow>)}</TableBody></Table></TableContainer>
      {detail.overheads && detail.overheads.length > 0 && <><Typography variant="subtitle2" sx={{ fontWeight: 700, mt: 2, mb: 1 }}>Overheads</Typography><TableContainer component={Paper} sx={{ overflowX: "auto" }}><Table size="small" sx={{ minWidth: 320 }}><TableHead><TableRow><TableCell>Type</TableCell><TableCell>Name</TableCell><TableCell>Employee</TableCell><TableCell>Cost</TableCell></TableRow></TableHead><TableBody>{detail.overheads.map((oh: any, i: number) => <TableRow key={i}><TableCell>{oh.overhead_type}</TableCell><TableCell>{oh.name}</TableCell><TableCell>{oh.employee_name || "-"}</TableCell><TableCell>{formatMoney(oh.cost)}</TableCell></TableRow>)}</TableBody></Table></TableContainer></>}</Box>}</DialogContent><DialogActions><Button onClick={openEdit} disabled={!detail || detailLoading}>Edit batch</Button><Button onClick={() => setDetailId(null)}>Close</Button></DialogActions></Dialog>
    <Dialog open={editOpen} onClose={() => { setEditOpen(false); setError(""); }} maxWidth="sm" fullWidth><DialogTitle>Update batch record</DialogTitle><DialogContent>{error && <Alert severity="error" sx={{ mb: 1 }}>{error}</Alert>}<Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>Produced quantity is fixed after recording because it is tied to ingredient consumption and stock.</Typography><TextField fullWidth margin="dense" label="Produced quantity" type="number" value={editQty} disabled /><TextField fullWidth margin="dense" label="Production date" type="date" value={editDate} onChange={(event) => setEditDate(event.target.value)} slotProps={{ inputLabel: { shrink: true } }} /><TextField fullWidth margin="dense" label="Total selling revenue (optional)" type="number" value={editPrice} onChange={(event) => setEditPrice(event.target.value)} /></DialogContent><DialogActions><Button onClick={() => setEditOpen(false)}>Cancel</Button><Button variant="contained" onClick={saveEdit} disabled={updateBatch.isPending}>Save changes</Button></DialogActions></Dialog>
    <Snackbar open={!!success} autoHideDuration={3500} onClose={() => setSuccess("")}><Alert severity="success" variant="filled">{success}</Alert></Snackbar>
  </Box>;
};
